import React from 'react'

type Props = {}

const Index = (props: Props) => {
  return (
    <div>Index</div>
  )
}