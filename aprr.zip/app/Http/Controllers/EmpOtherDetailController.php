<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EmpOtherDetailController extends Controller
{
    //
}
