<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EmpProfessionalQualificationController extends Controller
{
    //
}
