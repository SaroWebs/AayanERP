<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClientContactDetailController extends Controller
{
    //
}
